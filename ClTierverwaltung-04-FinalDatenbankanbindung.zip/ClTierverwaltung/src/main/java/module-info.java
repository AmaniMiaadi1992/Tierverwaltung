module de.cloch.cltierverwaltung {
    requires javafx.controls;
    requires javafx.fxml;
//    TODO 0.1 java.sql und org.mariadb.jdbc in module-info.java als required definieren
    requires org.mariadb.jdbc;
    requires java.sql;


    opens de.cloch.cltierverwaltung to javafx.fxml;
    exports de.cloch.cltierverwaltung;
    exports de.cloch.cltierverwaltung.gui;
    opens de.cloch.cltierverwaltung.gui to javafx.fxml;
}