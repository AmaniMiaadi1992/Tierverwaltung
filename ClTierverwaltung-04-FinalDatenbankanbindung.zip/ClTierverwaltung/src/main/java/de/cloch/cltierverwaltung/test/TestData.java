package de.cloch.cltierverwaltung.test;

import de.cloch.cltierverwaltung.model.Animal;

import java.util.ArrayList;
import java.util.List;

/**
 * Klasse, welche Testdaten generiert und zurückliefert
 */
public class TestData {
    //region Konstanten
    public static final int TEST_ANIMAL_AMOUNT = 10;
    //endregion

    //region Attribute
    //endregion

    //region Konstruktoren
    private TestData() {}
    //endregion

    //region Methoden
    public static List<Animal> getTestAnimals() {
        List<Animal> testAnimals = new ArrayList<>();

        Animal mouse = new Animal("Maus", "Mickey", 20);
        Animal dog = new Animal("Hund", "Bello", 4);
        Animal shivaCat = new Animal("Katze", "Shiva", 1);
        Animal shivaDog = new Animal("Hund", "Shiva", 3);
        Animal sora = new Animal("Wellensittich", "Sora", 4);

        testAnimals.add(mouse);
        testAnimals.add(dog);
        testAnimals.add(shivaCat);
        testAnimals.add(shivaDog);
        testAnimals.add(sora);

        return testAnimals;
    }
    //endregion
}
