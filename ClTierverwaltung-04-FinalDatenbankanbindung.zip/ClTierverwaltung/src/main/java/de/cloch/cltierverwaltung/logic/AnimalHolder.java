package de.cloch.cltierverwaltung.logic;

import de.cloch.cltierverwaltung.logic.database.DbManager;
import de.cloch.cltierverwaltung.model.Animal;
import de.cloch.cltierverwaltung.settings.AppTexts;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;

import java.util.Comparator;

/**
 * Klasse, welche alle Tiere als ObservableList bereitstellt
 */
public class AnimalHolder {
    //region Konstanten
    //endregion

    //region Attribute
    private static AnimalHolder instance;
    private ObservableList<Animal> animals;
    //endregion

    //region Konstruktoren
    private AnimalHolder() {
        //Leere Liste erzeugen und Observables die eine Tier zugewiesen sind selbst definieren
//        TODO 4 Properties der Tiere als Observables mit ObservableList verknüpfen
        animals = FXCollections.observableArrayList(animal -> new Observable[] {
                animal.speciesProperty(), animal.nameProperty(), animal.ageProperty()
        });

        //Liste mit Tieren anhand Testdaten befüllen
//        animals.addAll(TestData.getTestAnimals());

//        TODO 4.1 Liste durch auslesen der Datenbank befüllen
        //Liste mit Tieren anhand der Datenbank befüllen
        animals.addAll(DbManager.getInstance().readAllDataRecords());

        //ListChangeListener zuweisen, der bei Änderungen an der Liste animals benachrichtigt wird
//        TODO 4.2 ListChangeListener implementieren, sodass Änderungen der Liste in die Datenbank übertragen werden
        animals.addListener((ListChangeListener<Animal>) change -> {

//            System.out.println(change);

            while (change.next()) {

                if (change.wasAdded()) {

                    Animal animalToInsert = change.getAddedSubList().get(0);
                    DbManager.getInstance().insertDataRecord(animalToInsert);

                } else if (change.wasUpdated()) {

                    int updatedIndex = change.getFrom();
                    Animal animalToUpdate = change.getList().get(updatedIndex);
                    DbManager.getInstance().updateDataRecord(animalToUpdate);

                } else if (change.wasRemoved()) {

                    Animal animalToDelete = change.getRemoved().get(0);
                    DbManager.getInstance().deleteDataRecord(animalToDelete);

                } else if (change.wasReplaced()) {

                    System.out.println(AppTexts.TXT_LIST_ELEMENT_REPLACED);

                } else if (change.wasPermutated()){

                    System.out.println(AppTexts.TXT_LIST_SORTED);
                }
            }
        });
    }
    //endregion

    //region Methoden
    public static synchronized AnimalHolder getInstance() {
        if (instance == null) instance = new AnimalHolder();
        return instance;
    }

    public ObservableList<Animal> getAnimals() {
        return animals;
    }

    public void sortAnimalsBySpecies() {
        animals.sort((animal, followingAnimal) -> {
            String animalSpecies = animal.getSpecies();
            String followingAnimalSpecies = followingAnimal.getSpecies();

            return animalSpecies.compareTo(followingAnimalSpecies);
        });
    }

    public void sortAnimalsByName() {
        animals.sort(Comparator.comparing(Animal::getName));
    }

    public void sortAnimalsByAge() {
        //Lambda Schreibweise (kürzer, weniger nachvollziehbar)
        animals.sort((animal, followingAnimal) -> {
//            int animalAge = animal.getAge();
//            int followingAnimalAge = followingAnimal.getAge();
//
//            return animalAge - followingAnimalAge;

            Integer animalAge = animal.getAge();
            Integer followingAnimalAge = followingAnimal.getAge();

            return animalAge.compareTo(followingAnimalAge);
        });

        //Normale Schreibweise (länger, besser nachvollziehbar)
//        animals.sort(new Comparator<Animal>() {
//            @Override
//            public int compare(Animal animal, Animal followingAnimal) {
//                Integer animalAge = animal.getAge();
//                Integer followingAnimalAge = followingAnimal.getAge();
//
//                return animalAge.compareTo(followingAnimalAge);
//            }
//        });
    }

    public void sortAnimalsByNameAndAge() {
        animals.sort((animal, followingAnimal) -> {
            String animalName = animal.getName();
            String followingAnimalName = followingAnimal.getName();

            int nameCompareResult = animalName.compareTo(followingAnimalName);

            if (nameCompareResult != 0) return nameCompareResult;

            Integer animalAge = animal.getAge();
            Integer followingAnimalAge = followingAnimal.getAge();

            return -animalAge.compareTo(followingAnimalAge);
        });
    }

    //endregion
}
