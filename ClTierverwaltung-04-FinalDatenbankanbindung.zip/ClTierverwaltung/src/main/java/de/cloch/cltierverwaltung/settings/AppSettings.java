package de.cloch.cltierverwaltung.settings;

import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;

/**
 * Definiert App-Einstellungen als Konstanten
 */
public class AppSettings {
    //region Konstanten
    public static final int LIST_VIEW_SELECTION_CLICK_COUNT = 2;
    public static final KeyCode LIST_VIEW_SELECTION_KEY = KeyCode.ENTER;
    public static final MouseButton LIST_VIEW_SELECTION_MOUSE_BUTTON = MouseButton.PRIMARY;
    //endregion

    //region Attribute
    //endregion

    //region Konstruktoren
    private AppSettings() {}
    //endregion

    //region Methoden
    //endregion
}
