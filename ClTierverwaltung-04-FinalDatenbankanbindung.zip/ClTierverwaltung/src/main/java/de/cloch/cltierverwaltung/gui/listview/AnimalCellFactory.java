package de.cloch.cltierverwaltung.gui.listview;

import de.cloch.cltierverwaltung.model.Animal;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.util.Callback;

/**
 * Bestimmt welche Zellen einer ListView aufgebaut werden sollen
 */
public class AnimalCellFactory implements Callback<ListView<Animal>, ListCell<Animal>> {
    //region Konstanten
    //endregion

    //region Attribute
    //endregion

    //region Konstruktoren
    //endregion

    //region Methoden

    /**
     * Baut für jedes Element der Liste innerhalb der ListView eine neue Zelle auf und
     * liefert diese zurück.
     *
     * @param animalListView The single argument upon which the returned value should be
     *      determined.
     *
     * @return {@link AnimalCell} : Objekt der eigenen Zellen-Klasse
     */
    @Override
    public ListCell<Animal> call(ListView<Animal> animalListView) {
        return new AnimalCell();
    }

    //endregion
}
