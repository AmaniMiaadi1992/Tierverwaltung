package de.cloch.cltierverwaltung.gui.listview;

import de.cloch.cltierverwaltung.model.Animal;
import de.cloch.cltierverwaltung.settings.AppTexts;
import javafx.scene.control.ListCell;

/**
 * Bestimmt wie eine Zelle einer ListView angezeigt werden soll
 */
public class AnimalCell extends ListCell<Animal> {
    //region Konstanten
    //endregion

    //region Attribute
    //endregion

    //region Konstruktoren
    //endregion

    //region Methoden

    /**
     * Aktualisiert den Inhalt einer Zelle und zeigt ihn
     * auf die implementierte Art und Weise an.
     *
     * @param animalToShow : {@link Animal} : Das anzuzeigende Tier
     * @param isEmpty : boolean : Gibt an, ob die Zelle leer sein soll
     */
    @Override
    protected void updateItem(Animal animalToShow, boolean isEmpty) {
        super.updateItem(animalToShow, isEmpty);

        if (isEmpty || animalToShow == null) {
            setText(null);
            setGraphic(null);
        } else {
            setText(String.format(AppTexts.ANIMAL_FORMAT_STRING,
                    animalToShow.getSpecies(), animalToShow.getName(), animalToShow.getAge()));
        }
    }

    //endregion
}
