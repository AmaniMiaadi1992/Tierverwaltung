package de.cloch.cltierverwaltung.logic.database;

import de.cloch.cltierverwaltung.model.Animal;
import de.cloch.cltierverwaltung.settings.AppTexts;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

/**
 * Baut Verbindungen zu Datenbanken auf
 * und hat Zugriff auf die jeweiligen Dao-Objekte
 * alle Modellklassen des Projektes.
 *
 * STRG + C - lagert einen Wert in Konstante aus
 * F6 - verschiebt Klassenbestandteile in andere Klassen
 * TODO 3 DbManager implementieren
 */
public class DbManager {

    //region Konstanten
    //endregion

    //region Attribute
    private static DbManager instance;

    private final DaoAnimals daoAnimals;
    //endregion

    //region Konstruktoren
    private DbManager() {
        daoAnimals = new DaoAnimals();
    }
    //endregion

    //region Methoden
    public static synchronized DbManager getInstance() {
        if (instance == null) instance = new DbManager();
        return instance;
    }

    private Connection getConnection() {

        Connection dbConnection = null;

        try {

        dbConnection = DriverManager.getConnection(AppTexts.DB_URL, AppTexts.USERNAME, AppTexts.PASSWORD);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return dbConnection;
    }

    /**
     * Fügt einen Datensatz in die Datenbank anhand eines übergebenen Objektes ein.
     * @param object : {@link Object} : Objekt zum Einfügen
     */
    public void insertDataRecord(Object object) {
        if (object instanceof Animal animal) daoAnimals.create(getConnection(), animal);
        else System.out.println(AppTexts.TXT_INSERT_FAILED);
    }

    /**
     * Liest alle Datensätze der Datenbank aus.
     */
    public List<Animal> readAllDataRecords() {
        return daoAnimals.readAll(getConnection());
    }

    /**
     * Aktualisiert einen Datensatz in der Datenbank anhand eines übergebenen Objektes.
     * @param object : {@link Object} : Objekt zum Aktualisieren
     */
    public void updateDataRecord(Object object) {
        if (object instanceof Animal animal) daoAnimals.update(getConnection(), animal);
        else System.out.println(AppTexts.TXT_UPDATE_FAILED);
    }

    /**
     * Löscht einen Datensatz aus der Datenbank anhand eines übergebenen Objektes.
     * @param object : {@link Object} : Objekt zum Löschen
     */
    public void deleteDataRecord(Object object) {
        if (object instanceof Animal animal) daoAnimals.delete(getConnection(), animal);
        else System.out.println(AppTexts.TXT_DELETE_FAILED);
    }

    //endregion
}
