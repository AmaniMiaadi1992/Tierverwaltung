package de.cloch.cltierverwaltung.gui;

import de.cloch.cltierverwaltung.Main;
import de.cloch.cltierverwaltung.model.Animal;
import de.cloch.cltierverwaltung.settings.AppTexts;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Ist zuständig für den Wechsel von Szenen im Programm
 */
public class SceneManager {
    //region Konstanten
    //endregion

    //region Attribute
    private static SceneManager instance;
    private Stage mainStage;
    //endregion

    //region Konstruktoren
    private SceneManager() {}
    //endregion

    //region Methoden
    public static synchronized SceneManager getInstance() {
        if (instance == null) instance = new SceneManager();
        return instance;
    }

    public void setAndConfigureMainStage(Stage stage) {
        mainStage = stage;
        mainStage.setTitle(AppTexts.APP_NAME);
        switchToOverviewScene();
    }

    public void switchToOverviewScene() {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("overview-scene.fxml"));
        try {
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            switchScene(scene);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Wechselt zur Detail-Szene und überträgt das ausgewählte Tier
     *
     * @param selectedAnimal : {@link Animal} : Das in der OverView-Szene ausgewählte Tier
     */
    public void switchToDetailScene(Animal selectedAnimal) {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("detail-scene.fxml"));
        try {
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);

            //Controller über FxmlLoader beschaffen
            DetailController detailController = fxmlLoader.getController();
            //Über das Controller Objekt das selektierte Tier setzen
            detailController.setSelectedAnimal(selectedAnimal);

            switchScene(scene);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void switchScene(Scene scene) {
        mainStage.setScene(scene);
        mainStage.show();
    }
    //endregion
}
