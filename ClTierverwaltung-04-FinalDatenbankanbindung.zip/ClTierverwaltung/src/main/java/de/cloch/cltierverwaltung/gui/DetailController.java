package de.cloch.cltierverwaltung.gui;

import de.cloch.cltierverwaltung.logic.AnimalHolder;
import de.cloch.cltierverwaltung.model.Animal;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * Enthält die Steuerlogik für die Detail-Szene
 */
public class DetailController {
    //region Konstanten
    //endregion

    //region Attribute
    private Animal selectedAnimal;

    @FXML
    private TextField txtSpecies;
    @FXML
    private TextField txtName;
    @FXML
    private TextField txtAge;

    @FXML
    private Button btnConvey;
    //endregion

    //region Konstruktoren
    //endregion

    //region Methoden

    public void setSelectedAnimal(Animal selectedAnimal) {
        this.selectedAnimal = selectedAnimal;
        if (selectedAnimal != null) showAnimalDetails();
        else btnConvey.setDisable(true);
    }

    private void showAnimalDetails() {
        txtSpecies.setText(selectedAnimal.getSpecies());
        txtName.setText(selectedAnimal.getName());
        txtAge.setText(String.valueOf(selectedAnimal.getAge()));
    }

    @FXML
    private void saveAnimal() {
        if (selectedAnimal != null) {

            if (fieldIsNotBlankEmptyOrEqual(txtSpecies, selectedAnimal.getSpecies()))
                selectedAnimal.setSpecies(txtSpecies.getText());
            if (fieldIsNotBlankEmptyOrEqual(txtName, selectedAnimal.getName()))
                selectedAnimal.setName(txtName.getText());
            if (fieldIsNotBlankEmptyOrEqual(txtAge, String.valueOf(selectedAnimal.getAge())))
                selectedAnimal.setAge(Integer.parseInt(txtAge.getText()));

        } else {

            Animal newAnimal = new Animal(
                    txtSpecies.getText(),
                    txtName.getText(),
                    Integer.parseInt(txtAge.getText())
            );

            AnimalHolder.getInstance().getAnimals().add(newAnimal);
        }

        openOverviewScene();
    }

    @FXML
    private void conveyAnimal() {
        AnimalHolder.getInstance().getAnimals().remove(selectedAnimal);
        openOverviewScene();
    }

    private boolean fieldIsNotBlankEmptyOrEqual(TextField field, String value) {
        return  !field.getText().isBlank()
                && !field.getText().isEmpty()
                && !field.getText().equals(value);
    }

    @FXML
    private void openOverviewScene() {
        SceneManager.getInstance().switchToOverviewScene();
    }
    //endregion
}
