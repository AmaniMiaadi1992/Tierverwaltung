package de.cloch.cltierverwaltung.gui;

import de.cloch.cltierverwaltung.gui.listview.AnimalCellFactory;
import de.cloch.cltierverwaltung.logic.AnimalHolder;
import de.cloch.cltierverwaltung.model.Animal;
import de.cloch.cltierverwaltung.settings.AppSettings;
import de.cloch.cltierverwaltung.settings.AppTexts;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Enthält die Steuerlogik für die Overview-Szene
 */
public class OverviewController implements Initializable {
    //region Konstanten
    //endregion

    //region Attribute
    @FXML
    private ListView<Animal> animalListView;
    //endregion

    //region Konstruktoren
    //endregion

    //region Methoden

    /**
     * Wird zwischen Laden einer Szene und Anzeigen der Szene aufgerufen, um
     * Elemente des Controllers dieser Szene zu initialisieren.
     * Vergleichbar mit den letzten Vorbereitungen bei einem Theaterstück,
     * bevor sich der Vorhang öffnet.
     *
     * @param location
     * The location used to resolve relative paths for the root object, or
     * {@code null} if the location is not known.
     *
     * @param resources
     * The resources used to localize the root object, or {@code null} if
     * the root object was not localized.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        //Eigene Factory der ListView zuweisen
        animalListView.setCellFactory(new AnimalCellFactory());

        //ListView mit Elementen befüllen
        animalListView.setItems(AnimalHolder.getInstance().getAnimals());

        animalListView.setOnMouseClicked(mouseEvent -> {
            if (mouseEvent.getClickCount() == AppSettings.LIST_VIEW_SELECTION_CLICK_COUNT
                    && mouseEvent.getButton() == AppSettings.LIST_VIEW_SELECTION_MOUSE_BUTTON) {
                Animal selectedAnimal = animalListView.getSelectionModel().getSelectedItem();
                SceneManager.getInstance().switchToDetailScene(selectedAnimal);
            }
        });

        animalListView.setOnKeyPressed(keyEvent -> {
            if (keyEvent.getCode() == AppSettings.LIST_VIEW_SELECTION_KEY) {
                Animal selectedAnimal = animalListView.getSelectionModel().getSelectedItem();
                SceneManager.getInstance().switchToDetailScene(selectedAnimal);
            }
        });
    }

    @FXML
    private void openDetailScene() {
        SceneManager.getInstance().switchToDetailScene(null);
    }

    @FXML
    private void sortAnimals(ActionEvent actionEvent) {
        if (actionEvent.getSource() instanceof Button sortButton) {
            switch (sortButton.getText()) {
                case AppTexts.SPECIES -> AnimalHolder.getInstance().sortAnimalsBySpecies();
                case AppTexts.NAME -> AnimalHolder.getInstance().sortAnimalsByName();
                case AppTexts.AGE -> AnimalHolder.getInstance().sortAnimalsByAge();
                default -> System.out.println(AppTexts.TXT_INVALID_SORT_BUTTON);
            }
        }
    }
    //endregion
}