package de.cloch.cltierverwaltung.settings;

/**
 * Stellt Programmtexte als Konstante zur Verfügung
 */
public class AppTexts {

    //region Konstanten
    public static final String ANIMAL_FORMAT_STRING = "%20s %20s %10s";
    public static final String APP_NAME = "Cl Tierverwaltung";
    public static final String SPECIES = "Tierart";
    public static final String NAME = "Name";
    public static final String AGE = "Alter";
    public static final String TXT_INVALID_SORT_BUTTON = "Ungültiger Knopf zum Sortieren gedrückt. Liste kann nicht sortiert werden.";
    public static final String SERVER_IP = "localhost";
    public static final String DB_NAME = "tierverwaltung";
    public static final String DB_URL = "jdbc:mariadb://" + SERVER_IP + "/" + DB_NAME;
    public static final String USERNAME = "root";
    public static final String PASSWORD = "";
    public static final String TXT_LIST_ELEMENT_REPLACED = "Element der Liste wurde ersetzt";
    public static final String TXT_LIST_SORTED = "Liste wurde sortiert";
    public static final String TXT_INSERT_FAILED = "Ungültiges Objekt! Speichern in Datenbank fehlgeschlagen.";
    public static final String TXT_UPDATE_FAILED = "Ungültiges Objekt! Aktualisieren in Datenbank fehlgeschlagen.";
    public static final String TXT_DELETE_FAILED = "Ungültiges Objekt! Löschen aus Datenbank fehlgeschlagen.";
    //endregion

    //region Attribute
    //endregion

    //region Konstruktoren
    private AppTexts() {}
    //endregion

    //region Methoden
    //endregion
}
