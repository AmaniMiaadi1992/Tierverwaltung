package de.cloch.cltierverwaltung.logic.database;

import java.sql.Connection;
import java.util.List;

/**
 * Interface, welches Methoden für CRUD-Operationen bereitstellt.<br>
 * <b>D</b>ata <b>A</b>ccess <b>O</b>bject
 *
 * @param <T> : Der Datentyp der zu verwaltenden Objekte
 *           TODO 1 Dao-Interface implementieren
 */
public interface Dao<T> {

    /**
     * Methode zum Einfügen eines Objektes in die Datenbank
     *
     * @param dbConnection : {@link Connection} : Offene Verbindung zur Datenbank
     * @param object : Das zu speichernde Objekt einer bestimmten Modellklasse
     */
    void create(Connection dbConnection, T object);

    /**
     * Methode zum Auslesen von Objekten aus der Datenbank
     *
     * @param dbConnection : {@link Connection} : Offene Verbindung zur Datenbank
     *
     * @return Liste von Objekten einer bestimmten Modellklasse
     */
    List<T> readAll(Connection dbConnection);

    /**
     * Methode zum Aktualisieren eines Objektes in der Datenbank
     *
     * @param dbConnection : {@link Connection} : Offene Verbindung zur Datenbank
     * @param object : Das zu aktualisierende Objekt einer bestimmten Modellklasse
     */
    void update(Connection dbConnection, T object);

    /**
     * Methode zum Löschen eines Objektes aus der Datenbank
     *
     * @param dbConnection : {@link Connection} : Offene Verbindung zur Datenbank
     * @param object : Das zu löschende Objekt einer bestimmten Modellklasse
     */
    void delete(Connection dbConnection, T object);
}
