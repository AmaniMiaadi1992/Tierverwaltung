package de.cloch.cltierverwaltung.logic.database;

import de.cloch.cltierverwaltung.model.Animal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Spezielle Dao-Klasse für Tiere. Implementiert
 * die CRUD-Operationen speziell für Tiere anhand
 * deren Eigenschaften und Anhand der Tabellenstruktur
 * der Datenbank.
 * TODO 2 DaoAnimals implementieren
 */
public class DaoAnimals implements Dao<Animal> {


    //region Konstanten
    public static final String STATEMENT_SELECT_ANIMALS = "SELECT * FROM animals";
    public static final String COL_SPECIES = "species";
    public static final String COL_NAME = "name";
    public static final String COL_AGE = "age";
    public static final String COL_ID = "id";
    public static final String STATEMENT_UPDATE_ANIMAL = "UPDATE animals SET species=?, name=?, age=? WHERE id=?";
    public static final String STATEMENT_DELETE_ANIMAL = "DELETE FROM animals WHERE id=?";
    public static final String STATEMENT_INSERT_ANIMAL = "INSERT INTO animals (species, name, age) VALUES (?,?,?)";
    public static final String COL_INSERT_ID = "insert_id";
    //endregion

    //region Attribute
    //endregion

    //region Konstruktoren
    //endregion

    //region Methoden
    @Override
    public void create(Connection dbConnection, Animal animal) {
        PreparedStatement statement = null;

        try {

            statement = dbConnection.prepareStatement(STATEMENT_INSERT_ANIMAL, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, animal.getSpecies());
            statement.setString(2, animal.getName());
            statement.setInt(3, animal.getAge());

            statement.execute();

            ResultSet resultSet = statement.getGeneratedKeys();

            while (resultSet.next()) {
                int insertId = resultSet.getInt(COL_INSERT_ID);
                animal.setId(insertId);
                System.out.println(animal);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Statement und Datenbankverbindung schließen
            try {
                if (statement != null) statement.close();
                dbConnection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public List<Animal> readAll(Connection dbConnection) {
        List<Animal> animals = new ArrayList<>();

        Statement statement = null;

        try {

            //Statement Objekt über die Datenbankverbindung generieren
            statement = dbConnection.createStatement();

            //SQL-Befehl über Statement-Objekt ausführen und Ergebnis in ResultSet-Objekt speichern
            ResultSet resultSet = statement.executeQuery(STATEMENT_SELECT_ANIMALS);

            //ResultSet durchlaufen und aus jedem Datensatz ein neues Tier anlegen und der Liste hinzufügen
            while(resultSet.next()) {
                Animal animal = new Animal(
                        resultSet.getString(COL_SPECIES),
                        resultSet.getString(COL_NAME),
                        resultSet.getInt(COL_AGE)
                );
                animal.setId(resultSet.getInt(COL_ID));

                animals.add(animal);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Statement und Datenbankverbindung schließen
            try {
                if (statement != null) statement.close();
                dbConnection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return animals;
    }

    @Override
    public void update(Connection dbConnection, Animal animal) {
        PreparedStatement statement = null;

        try {

            statement = dbConnection.prepareStatement(STATEMENT_UPDATE_ANIMAL);
            statement.setString(1, animal.getSpecies());
            statement.setString(2, animal.getName());
            statement.setInt(3, animal.getAge());
            statement.setInt(4, animal.getId());

            statement.execute();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Statement und Datenbankverbindung schließen
            try {
                if (statement != null) statement.close();
                dbConnection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void delete(Connection dbConnection, Animal animal) {
        PreparedStatement statement = null;

        try {

            statement = dbConnection.prepareStatement(STATEMENT_DELETE_ANIMAL);
            statement.setInt(1, animal.getId());

            statement.execute();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //Statement und Datenbankverbindung schließen
            try {
                if (statement != null) statement.close();
                dbConnection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    //endregion
}
