package de.cloch.cltierverwaltung;

import de.cloch.cltierverwaltung.gui.SceneManager;
import de.cloch.cltierverwaltung.model.Animal;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Einstiegspunkt des Programmes
 */
public class Main extends Application {

    @Override
    public void start(Stage mainStage) throws IOException {
        SceneManager.getInstance().setAndConfigureMainStage(mainStage);
    }

    public static void main(String[] args) {
        launch();
    }
}